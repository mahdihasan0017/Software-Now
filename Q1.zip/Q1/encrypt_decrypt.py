def encrypt_text(shift1, shift2):
    def shift_char(char, shift1, shift2):
       
        if "a" <= char <= "m":
            return chr(((ord(char) - ord("a") + (shift1 * shift2)) % 13) + ord("a"))
        elif "n" <= char <= "z":
            return chr(((ord(char) - ord("n") - (shift1 + shift2)) % 13) + ord("n"))
        
        elif "A" <= char <= "M":
            return chr(((ord(char) - ord("A") - shift1) % 13) + ord("A"))
        elif "N" <= char <= "Z":
            return chr(((ord(char) - ord("N") + (shift2**2)) % 13) + ord("N"))
        else:
            return char

    try:
        with open("raw_text.txt", "r") as file:
            raw_text = file.read()

        
        encrypted_text = "".join(shift_char(char, shift1, shift2) for char in raw_text)

        
        with open("encrypted_text.txt", "w") as file:
            file.write(encrypted_text)
            print("Encrypted Text:", encrypted_text)

        print("\nEncryption complete. Encrypted text saved to 'encrypted_text.txt'.")
        return encrypted_text
    except FileNotFoundError:
        print("File 'raw_text.txt' not found.")


def decrypt_text(shift1, shift2):
    def reverse_shift_char(char, shift1, shift2):
       
        if "a" <= char <= "m":
            return chr(((ord(char) - ord("a") - (shift1 * shift2)) % 13) + ord("a"))
        elif "n" <= char <= "z":
            return chr(((ord(char) - ord("n") + (shift1 + shift2)) % 13) + ord("n"))
        
        elif "A" <= char <= "M":
            return chr(((ord(char) - ord("A") + shift1) % 13) + ord("A"))
        elif "N" <= char <= "Z":
            return chr(((ord(char) - ord("N") - (shift2**2)) % 13) + ord("N"))
        else:
            return char

    try:
        with open("encrypted_text.txt", "r") as file:
            encrypted_text = file.read()

        
        decrypted_text = "".join(
            reverse_shift_char(char, shift1, shift2) for char in encrypted_text
        )

        
        with open("decrypted_text.txt", "w") as file:
            file.write(decrypted_text)
            print("\nDecrypted Text:", decrypted_text)

        print("\nDecryption complete. Decrypted text saved to 'decrypted_text.txt'.")
        return decrypted_text
    except FileNotFoundError:
        print("File 'encrypted_text.txt' not found.")
        return ""


def verify_decryption(raw_text, decrypted_text):
    if raw_text == decrypted_text:
        print(
            "\nDecryption successfully verified: The original and decrypted texts match."
        )
    else:
        print("\nDecryption failed: The original and decrypted texts do not match.")



if __name__ == "__main__":
    
    shift1 = int(input("Enter the value for shift1: "))
    shift2 = int(input("Enter the value for shift2: "))

    
    encrypted_text = encrypt_text(shift1, shift2)

    try:
        
        with open("raw_text.txt", "r") as file:
            original_text = file.read()

        
        decrypted = decrypt_text(shift1, shift2)

        
        verify_decryption(original_text, decrypted)

    except FileNotFoundError:
        print("File 'raw_text.txt' not found. Cannot verify decryption.")
