import os
import csv
import numpy as np
from collections import defaultdict


input_folder = os.path.join("Temperatures")  # Corrected path
average_temp_file = "average_temp.txt"
largest_temp_range_file = "largest_temp_range_station.txt"
stability_file = "temperature_stability_stations.txt"


seasons = {
    "Summer": ["December", "January", "February"],
    "Autumn": ["March", "April", "May"],
    "Winter": ["June", "July", "August"],
    "Spring": ["September", "October", "November"]
}

def process_files():
    seasonal_temps = defaultdict(list)
    station_data = {}

    
    if not os.path.isdir(input_folder):
        print(f"Error: The directory '{input_folder}' does not exist.")
        return seasonal_temps, station_data

    for filename in os.listdir(input_folder):
        if filename.endswith(".csv"):
            print(f"Processing file: {filename}")
            filepath = os.path.join(input_folder, filename)
            with open(filepath, 'r') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    station = row["STATION_NAME"]
                    
                    temps = []
                    for month in ["January","February","March","April","May","June",
                                  "July","August","September","October","November","December"]:
                        try:
                            temp = float(row[month])
                            temps.append(temp)
                            
                            for season, months in seasons.items():
                                if month in months:
                                    seasonal_temps[season].append(temp)
                        except (ValueError, KeyError):
                            
                            continue
                    
                    
                    if temps:
                        station_data[station] = temps
    return seasonal_temps, station_data


def save_seasonal_averages(seasonal_temps):
    with open(average_temp_file, "w") as f:
        for season, temps in seasonal_temps.items():
            if temps:
                avg = np.mean(temps)
                f.write(f"{season}: {avg:.2f}°C\n")


def save_largest_temp_range(station_data):
    largest_range = -1
    best_stations = []
    with open(largest_temp_range_file, "w") as f:
        for station, temps in station_data.items():
            if temps:
                tmax, tmin = max(temps), min(temps)
                trange = tmax - tmin
                if trange > largest_range:
                    largest_range = trange
                    best_stations = [(station, tmax, tmin, trange)]
                elif trange == largest_range:
                    best_stations.append((station, tmax, tmin, trange))
        
        for s, tmax, tmin, trange in best_stations:
            f.write(f"{s}: Range {trange:.2f}°C (Max: {tmax:.2f}°C, Min: {tmin:.2f}°C)\n")


def save_stability(station_data):
     
    stabilities = {}
    for station, temps in station_data.items():
       
        if temps and len(temps) > 1:
            stabilities[station] = np.std(temps)

    
    if not stabilities:
        print("Warning: No valid station data found for stability analysis.")
        with open(stability_file, "w") as f:
            f.write("No valid station data found for stability analysis.\n")
        return

    
    min_std = min(stabilities.values())
    max_std = max(stabilities.values())

    
    most_stable = [station for station, std in stabilities.items() if std == min_std]
    most_variable = [station for station, std in stabilities.items() if std == max_std]

    
    with open(stability_file, "w") as f:
        
        for s in most_stable:
            f.write(f"Most Stable: {s}: StdDev {min_std:.2f}°C\n")
        
       
        for s in most_variable:
            f.write(f"Most Variable: {s}: StdDev {max_std:.2f}°C\n")

    # print(f"Temperature stability analysis results saved to {stability_file}")


def main():
    """
    Main function to orchestrate the climate analysis process.
    """
    print("Starting climate analysis...")
    
    seasonal_temps, station_data = process_files()
    
    if not station_data:
        print("No valid station data was processed. Exiting.")
        return

    print("Analysis complete. Generating output files...")
    
    # Save the results to files
    save_seasonal_averages(seasonal_temps)
    save_largest_temp_range(station_data)
    save_stability(station_data)

    
    # Provide a brief summary of the contents
    try:
        with open(average_temp_file, "r") as f:
            print("\nSeasonal Averages:")
            print(f.read())
        
        with open(largest_temp_range_file, "r") as f:
            print("Largest Temperature Range:")
            print(f.read())
            
        with open(stability_file, "r") as f:
            print("Temperature Stability:")
            print(f.read())
            
    except FileNotFoundError as e:
        print(f"Error: Could not read a generated file. {e}")

if __name__ == "__main__":
    main()