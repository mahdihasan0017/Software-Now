import turtle
import math


def fractal_edge_inward(t, length, depth, inward_angle=60):
    if depth == 0:
        t.forward(length)
    else:
        l = length / 3.0
        fractal_edge_inward(t, l, depth - 1, inward_angle)
        
        t.right(inward_angle)        
        fractal_edge_inward(t, l, depth - 1, inward_angle)
        t.left(2 * inward_angle)      
        fractal_edge_inward(t, l, depth - 1, inward_angle)
        t.right(inward_angle)         
        fractal_edge_inward(t, l, depth - 1, inward_angle)



def fractal_polygon(sides, length, depth):
    t = turtle.Turtle()
    t.speed(0)
    t.hideturtle()
    angle = 360.0 / sides
    
    
    inward_angle = 60
    
    
    t.penup()
    t.goto(-length/2, -length/2)
    t.pendown()
    
    for i in range(sides):
        fractal_edge_inward(t, length, depth, inward_angle)
        t.right(angle)
    
    turtle.done()



sides = int(input("Enter the number of sides: "))
length = float(input("Enter the side length: "))
depth = int(input("Enter the recursion depth: "))


fractal_polygon(sides, length, depth)